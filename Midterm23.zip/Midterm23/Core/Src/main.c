#include "stm32f4xx.h"

#define LEDPINNUMBER GPIO_PIN_14
#define DURATION 16020
#define ARRNUMBER (uint16_t)(65536-1)

void Timer7_Init(void);

int main(void)
{
  RCC->AHB1ENR |= RCC_AHB1ENR_GPIODEN;
  GPIOD->MODER |= GPIO_MODER_MODE14_0;
  Timer7_Init();

  while (1)
  {
	  if (TIM7-> CNT < DURATION)
	  {

    GPIOD->ODR ^= LEDPINNUMBER;
              TIM7->CNT = 1;
	  }
  }
}

void Timer7_Init(void)
{
  RCC->APB1ENR |= RCC_APB1ENR_TIM7EN;
  TIM7->PSC = 2;
  TIM7->ARR = ARRNUMBER;
  TIM7->CR1 |= TIM_CR1_CEN;
}
